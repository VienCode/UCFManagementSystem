<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>About Us</title>
</head>
<div class="events">  
        <div class = "event_box"> 
            <h2>About Unity Christian Fellowship </h2>
            <h3>We are called to go and make disciples of Jesus of all nations.</h3>
            <h3>Here at UCF, regardless of who you are and where you are today, you are very much welcome here. We have a loving community filled with people who would love to share their journey of faith with you.</h3>
            <h3>We hope to see you!<h3>
            <h3> EVENTS & SCHEDULE </h3>
            <h3>Service Schedules</h3>
            <h4>Sundays: 10:30AM</h4>
            <br><br>
            <h3>Midweek Corporate Prayer</h3>
            <h4>Wednesdays: 7:00PM</h4>
        </div>
    </div>
</html>