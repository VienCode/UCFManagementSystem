<?php
session_start();

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $mysqli = require __DIR__ . "/database.php";

    $role = $_POST["role"];
    $email = $_POST["email"];
    $password = $_POST["pwd"];

    if ($role === "admin") {
        $sql = "SELECT * FROM admin_accounts WHERE admin_username = ?";
        $id_field = "admin_id";
        $pass_field = "admin_password";
    } elseif ($role === "accountant") {
        $sql = "SELECT * FROM accountant_accounts WHERE accountant_username = ?";
        $id_field = "accountant_id";
        $pass_field = "accountant_password";
    } elseif ($role === "pastor") {
        $sql = "SELECT * FROM pastor_accounts WHERE pastor_username = ?";
        $id_field = "pastor_id";
        $pass_field = "pastor_password";
    } else {
        $is_invalid = true;
    }

    if (!$is_invalid) {
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && $password === $user[$pass_field]) {
            session_regenerate_id(true);

            $_SESSION["user_id"] = $user[$id_field];
            $_SESSION["role"] = $role;

            if ($role === "admin") {
                header("Location: index.php");
            } elseif ($role === "accountant") {
                header("Location: index.php");
            } elseif ($role === "pastor") {
                header("Location: index.php");
            }
            exit;
        }

        $is_invalid = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lexend+Deca:wght@100..900&family=Signika:wght@300..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body class="login_body">
    
    <div class="topnav">
        <img class= "ucf-topnav" src="images/ucf.png" alt="UCF Logo Top Nav">
        <a href="login.php" class="active">Back to Login</a>        
    </div>

    <div class="container-login">
        <div class="login">

            <img class= "ucf-logo" src="images/ucf.png" alt="Unity Christian Fellowship Logo">
            
            <h3>Admin Login</h3>

            <?php if ($is_invalid): ?>
                <em> Invalid Login </em>
            <?php endif; ?> 

            <form method="post">
                <input required class="customInput" type="text" name="email" placeholder="Username" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
                <br> <br>
                <input required class="customInput" type="password" name="pwd" placeholder="Password">
                <br> <br>
                <button class="customButton" name="role" value="admin">Login as Admin</button>
                <button class="customButton" name="role" value="accountant">Login as Accountant</button>
                <button class="customButton" name="role" value="pastor">Login as Pastor</button>
            </form>
        </div>
    </div>

</body>
</html>