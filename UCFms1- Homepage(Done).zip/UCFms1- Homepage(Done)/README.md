# UCFManagementSystem
a website/system for digitizing Unity Christian Fellowship's management processes.
